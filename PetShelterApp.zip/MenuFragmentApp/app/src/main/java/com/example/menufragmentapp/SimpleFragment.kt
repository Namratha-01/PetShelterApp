package com.example.menufragmentapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class SimpleFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_simple, container, false)

        val textView: TextView = view.findViewById(R.id.textView)
        val editText: EditText = view.findViewById(R.id.editText)
        val button: Button = view.findViewById(R.id.button)
        val spinner: Spinner = view.findViewById(R.id.spinner)
        val radioGroup: RadioGroup = view.findViewById(R.id.radioGroup)

        // Set up the Spinner
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.sample_spinner_items,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        // Set up the Button click listener
        button.setOnClickListener {
            val inputText = editText.text.toString()
            val selectedRadioButtonId = radioGroup.checkedRadioButtonId
            val selectedRadioButton: RadioButton? = view.findViewById(selectedRadioButtonId)
            val selectedSpinnerItem = spinner.selectedItem.toString()

            val result = "Name: $inputText\nSelected Radio: ${selectedRadioButton?.text}\nSelected Spinner: $selectedSpinnerItem"
            textView.text = result
        }

        return view
    }
}