package com.example.menufragmentapp

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class SimpleDialogFragment : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setMessage("Please send the screenshots to: nam@gmail.com")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
    }
}